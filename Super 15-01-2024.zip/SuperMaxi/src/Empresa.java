import java.util.ArrayList;

public class Empresa {
    private final ArrayList<Producto> productos;
    private final ArrayList<Comprador> compradores;
    private String nombre;
    private int numeroDeProductos;

    private int numeroClientes;
    private Factura[] facturas;
    private int numeroFacturas;
    private int numFactura;
    public Empresa(String nombre) {

        this.nombre = nombre;
        numeroDeProductos = 0;
        numeroClientes = 0;
        facturas = new Factura[100];
        numeroFacturas = 0;
        numFactura = 0;
        this.productos = new ArrayList<>();
        this.compradores = new ArrayList<>();
    }

    public Producto agregarProducto(Producto producto) {
        this.productos.add(producto);
        return producto;
    }

    public void imprimirInventario() {
        System.out.println("INVENTARIO "+ nombre);
        for (Producto producto : productos) {
            if (producto == null) {
                return;
            }
            System.out.println("Producto: " + producto.getNombre() + " | Stock: " + producto.getStock());
        }
    }


    public double calcularPrecio(Producto producto) {
        return producto.calcularPrecio(producto);
    }


    public Cliente registrarCliente(Comprador comprador) {
        this.compradores.add(comprador);
        return comprador;
    }
    public void imprimirFactura(Factura factura) {
        System.out.println("-------------------------------------------------------------------------------");
        System.out.println("                                     "+nombre+"                               ");
        System.out.println("-------------------------------------------------------------------------------");
        System.out.println("Cliente: " + factura.getNombreCliente());
        //System.out.println("Fecha: " + factura.getFecha());
        //System.out.println("Número de Factura: " + factura.getNumFactura());
        System.out.println("-------------------------------------------------------------------------------");
        System.out.printf("%-20s %-20s %-20s %-20s\n", "Cantidad", "Producto", "Precio Unitario", "Total");
        System.out.println("-------------------------------------------------------------------------------");
        factura.imprimirProductos();
    }
}