public class Cliente {
    private final String cedula;
    private final String nombre;


    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public Cliente(String nombre , String cedula) {
        this.nombre = nombre;
        this.cedula = cedula;
    }

    @Override
    public String toString() {
        return "Cliente: " + nombre;
    }
}