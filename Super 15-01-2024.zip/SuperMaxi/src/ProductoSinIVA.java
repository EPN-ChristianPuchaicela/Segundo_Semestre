public  class ProductoSinIVA extends Producto {
    public ProductoSinIVA(String nombre, double precio, int stock) {
        super(nombre, precio, stock);
    }

    @Override
    public double calcularPrecio(Producto producto) {
        return getPrecio();
    }
}