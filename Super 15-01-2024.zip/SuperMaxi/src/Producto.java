public abstract class Producto {
    private int stock;
    private final double precio;
    private final String nombre;



    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }

    public int getStock() {
        return stock;
    }

    public Producto(String nombre, double precio, int stock) {
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }
    public void actualizarStock(int cantidad) {
        if(stock < cantidad){
            System.out.println("No hay productos disponibles");
        }
        stock -= cantidad;
    }

    public abstract double calcularPrecio(Producto producto);

    public double getUnitario() {
        return precio;
    }
}