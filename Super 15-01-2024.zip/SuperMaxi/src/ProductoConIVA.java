public class ProductoConIVA extends Producto {
    private final double IVA = 0.12;

    public ProductoConIVA(String nombre, double precio, int stock) {
        super(nombre, precio, stock);
    }

    @Override
    public double calcularPrecio(Producto producto) {
        return IVA ;
    }
}