import java.util.ArrayList;
import java.util.Date;

public class Factura {
    private final Cliente cliente;
    private ArrayList<Item> items;
    private Date fecha;
    private double subtotalPagar;
    private double totalIVAPagar;
    private double totalAPagar;

    public Factura(Cliente cliente) {
        this.items = new ArrayList<>();
        this.fecha = new Date();
        this.cliente = cliente;
        subtotalPagar = 0;
        totalIVAPagar = 0;
        totalAPagar =0;

    }

    public String getNombreCliente() {
        return cliente.getNombre();
    }

    public void añadirCarrito(Producto producto, int cantidad) {
        producto.actualizarStock(cantidad);
        if(cliente.getCedula().startsWith("11")){
            ProductoConIVAManabi productoManabi = new ProductoConIVAManabi(producto.getNombre(),
                    producto.getPrecio(),
                    producto.getStock());
            this.items.add(new Item(productoManabi, cantidad));
        }else{
            this.items.add(new Item(producto, cantidad ));
        }

    }


    public void imprimirProductos() {
    for (Item item : this.items){
        if(item == null){
            return;
        }
        System.out.printf("%-20d %-20s $%-19.2f $%-19.2f\n",item.getCantidad() , item.getNombreProducto() , item.getPrecioUnitario() , calcularPrecio(item));
        subtotalPagar += calcularPrecio(item);
        totalIVAPagar += calcularPrecio(item)*item.calcularIVAProducto();
    }
    totalAPagar=subtotalPagar+ totalIVAPagar;
        System.out.println("-------------------------------------------------------------------------------");
        System.out.printf("%-60s $%-19.2f\n", "Subtotal:", subtotalPagar);
        System.out.printf("%-60s $%-19.2f\n", "Total Iva:", totalIVAPagar);
        System.out.printf("%-60s $%-19.2f\n", "Total:", totalAPagar);
        System.out.println("-------------------------------------------------------------------------------");

    }

    public double calcularPrecio(Item item){
        return item.getCantidad()*item.getPrecioUnitario();
    }

}
