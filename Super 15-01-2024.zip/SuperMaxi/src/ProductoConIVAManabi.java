public class ProductoConIVAManabi extends Producto {

    private final double IVA = 0.08;
    public ProductoConIVAManabi(String nombre, double precio, int stock) {
        super(nombre, precio, stock);
    }

    @Override
    public double calcularPrecio(Producto producto) {
        return IVA ;
    }

}

