public class Main {
    public static void main(String[] args) {

        // Crear instancia de SuperMaxi
        Empresa superMaxi = new Empresa("SuperMaxi");
        System.out.println("Caso 1");
        // Crear productos y registrarlos
        Producto leche = superMaxi.agregarProducto(new ProductoSinIVA("Leche", 0.50, 100));
        Producto television = superMaxi.agregarProducto(new ProductoConIVA("Television", 534.56, 100));
        Producto tostadora = superMaxi.agregarProducto(new ProductoConIVAManabi("Tostadora", 85.45, 130));
        //Imprimir inventario
        superMaxi.imprimirInventario();
        //Crear UN CLIENTE
        Cliente cliente = superMaxi.registrarCliente(new Comprador("Christian Puchaicela", "1725447294"));
        // Agregar productos al supermercado
        Factura factura = new Factura(cliente);
        // Agregar productos a la factura
        factura.añadirCarrito(leche , 3);
        factura.añadirCarrito(television, 1);
        factura.añadirCarrito(tostadora , 3);
        //Confirmar que si se reduce el stock
        superMaxi.imprimirInventario();
        //Mostrar nuestra Factura
        superMaxi.imprimirFactura(factura);

        System.out.println("Caso 2");
        Cliente cliente2 = superMaxi.registrarCliente(new Comprador("Camila Lopez" , "1725447294" ));
        Factura factura2 = new Factura(cliente2);
        // Agregar productos a la factura
        factura2.añadirCarrito(leche , 3);
        factura2.añadirCarrito(television, 1);
        factura2.añadirCarrito(tostadora , 3);
        superMaxi.imprimirFactura(factura2);



    }
}