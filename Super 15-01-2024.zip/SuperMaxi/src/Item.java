public class Item {
    private final Producto producto;
    private final int cantidad;


    public Item(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;

    }

    public String getNombreProducto() {
        return producto.getNombre();
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitario() {
        return producto.getUnitario();
    }

    public double calcularIVAProducto(){
        return producto.calcularPrecio(producto);
    }
}
