public class CompradorManaba extends Cliente {


    public CompradorManaba(String nombre, String cedula) {
        super(nombre, cedula);
    }
}