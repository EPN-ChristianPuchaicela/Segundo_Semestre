public class Comprador extends Cliente{

    public Comprador(String nombre, String cedula) {
        super(nombre, cedula);
    }
}